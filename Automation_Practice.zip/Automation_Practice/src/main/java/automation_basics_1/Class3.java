package automation_basics_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Class3 {

    //Usage of ChromeDriver initialized in Class1 into Class3

    private WebDriver driver;

    public Class3(WebDriver driver) {
        this.driver = driver;
    }

    public static void main(String[] args) {

        Class1 C1 = new Class1();
        C1.navigateToMakeMyTrip();
        Class3 C3 = new Class3(C1.driver); //
        C3.dropdownPractice();

    }

    public void dropdownPractice() {

        driver.findElement(By.xpath("//span[text()='IN']")).click();
        driver.findElement(By.xpath("//p[@data-cy='selectCountry']")).click();
        for (int i =1;i<=3;i++) {
            WebElement element = driver.findElement(By.xpath("//p[@data-cy='GeographySections_24' ][" + i + "]"));
            String[][] dropdownvalues = {{"India"}, {"UAE"}, {"USA"}};
            for (String[] x : dropdownvalues) {
                for (String y : x) {
                    if (element.getText().equalsIgnoreCase("USA")) {
                        driver.findElement(By.xpath("//p[@data-cy='GeographySections_24' ][" + i + "]")).click();
                    }

                }


            }
        }

    }
}