package automation_basics_1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Class2 {

// usage of window handle within the URL
// refresh the page

WebDriver driver;
    public static void main(String[] args) throws InterruptedException {
    Class2 C2=new Class2();
    C2.getURL();
    C2.login();

    }

    public Class2(){
        System.setProperty("webdriver.chrome.driver","C:/ChromeDriver/chromedriver-win64/chromedriver.exe");
        this.driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    public void getURL(){
        driver.get("https://www.makemytrip.com");
    }

    public void login() throws InterruptedException {

        String number ="9999999999";
        driver.findElement(By.xpath("//p[text()='Login or Create Account']")).click();
        driver.switchTo().window(driver.getWindowHandle());
        driver.findElement(By.xpath("//input[@placeholder='Enter Mobile Number']")).sendKeys(number);
        driver.findElement(By.xpath("//li[text()='MyBiz Account']")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//input[@data-cy='MyBizLogin_119']")).sendKeys("gmail");
        Thread.sleep(2000);
        driver.navigate().refresh();

    }

}
