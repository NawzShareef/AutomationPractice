package automation_basics_1;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class Class4 {

    //Clicking on a particular Web element form a list of elements
    //Element not clickable - scroll to element method
    // Usage of WebDriver wait

    WebDriver driver;

    public Class4(WebDriver driver) {
        this.driver = driver;
    }

    public static void main(String[] args) throws InterruptedException {

        Class1 C1 = new Class1();
        C1.navigateToMakeMyTrip();
        Class4 C4 = new Class4(C1.driver);
        C4.headerMenu();

    }

    public static void scrollToElement(WebDriver driver, WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", element);
    }

    public void headerMenu() {

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

            List<WebElement> elements =
                    driver.findElements(By.xpath("//div[2]/div/main/main/div[1]/div[2]/ul/li/div/p/span"));
            for (WebElement x : elements) {
                wait.until(ExpectedConditions.visibilityOf(x));
                scrollToElement(driver,x);
                if(x.getText().equalsIgnoreCase("Where2Go")){
                  x.click();
                }

                }


            }

        }
