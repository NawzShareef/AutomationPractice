package automation_basics_7;

import org.openqa.selenium.WebDriver;

public class Runner {

    public static WebDriver driver;
    public Runner(WebDriver driver){
        this.driver = driver;
    }


    public static void main(String[] args) {

        Elements_2 E2 = new Elements_2();
        Runner E3 = new Runner(E2.driver);
        driver.get("https://www.makemytrip.com");
        driver.manage().window().maximize();
        E2.method1();
        E2.element.click();

        System.out.println("Al-Wahhab");
    }
}