    package automation_basics_7;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Elements_2 {


    //Usage of FindBy annotation to avoid using driver.findBy
    //Calling the method1 and using the constructor of this class in Runner class


    public WebDriver driver;

    public Elements_2(){
        System.setProperty("webdriver.chrome.driver","C:/ChromeDriver/chromedriver-win64/chromedriver.exe");
        driver = new ChromeDriver();
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath="//div[2]/div/div/nav/ul/li[2]/span/a/span[2]")
    public WebElement element;

    public void method1(){
        element.click();
    }
}
