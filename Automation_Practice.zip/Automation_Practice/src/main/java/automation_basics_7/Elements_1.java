package automation_basics_7;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Elements_1 {


    //Usage of FindBy annotation to avoid using driver.findBy
    private static WebDriver driver;

    public Elements_1(){
        System.setProperty("webdriver.chrome.driver","C:/ChromeDriver/chromedriver-win64/chromedriver.exe");
        driver = new ChromeDriver();
        PageFactory.initElements(driver,this); //
    }

    @FindBy(xpath="//div[2]/div/div/nav/ul/li[2]/span/a/span[2]")
    public WebElement element;

    public void method1(){

        element.click();
    }

    public static void main(String[] args) {
        Elements_1 steps = new Elements_1();
        driver.get("https://www.makemytrip.com");
        driver.manage().window().maximize();
        steps.method1();
    }



}
