package automation_basics_5;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

public class Configuration {

    //fetching the file and values present in it using InputStream and BufferedReader

    private static Properties properties;

    public static void load() throws IOException {

        properties=new Properties();
        InputStream is = new FileInputStream(new File("config.properties"));
        BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        try{
            properties.load(reader);
        }finally{
            is.close();
            reader.close();
        }
    }
    public static String get(String option) throws IOException {
        if(properties==null){
            load();
        }
        String value =properties.getProperty(option);
        if(value==null){
            return "";
        }
        return value;
    }

}
