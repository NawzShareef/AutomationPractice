package automation_basics_5;

public class Runner {


    public static void main(String[] args) throws Exception {

        All_DriverUsage.add(Configuration.get("browse"));
        All_DriverUsage.driver.get(Configuration.get("url"));
    }
}
