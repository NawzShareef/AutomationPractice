package automation_basics_5;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.safari.SafariDriver;
import java.util.HashMap;

public class All_DriverUsage {


        //Non usage of System.setProperty or setup command for initialization
        //All driver setup and initialization

        public static WebDriver driver;

        private static final HashMap<String, Class<?>> driverMap = new HashMap<String, Class<?>>() {
            {
                put("chrome", ChromeDriver.class);
                put("firefox", FirefoxDriver.class);
                put("ie", InternetExplorerDriver.class);
                put("safari", SafariDriver.class);

            }
        };

        public static WebDriver add(String browser) throws Exception {
            if (browser.equals(browser)) {
                Class<?> driverClass = driverMap.get(browser);
                driver = (WebDriver) driverClass.newInstance();
            }
            return driver;
        }

    }

