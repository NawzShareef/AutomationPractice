package automation_basics_2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.Set;

public class Class5 {

   //Usage of a common Webdriver wait class
    WebDriver driver;
public Class5(WebDriver driver){
    this.driver = driver;

}

    public static void main(String[] args) throws InterruptedException {

    Class1 C1 = new Class1();
    C1.navigateToMakeMyTrip();
    Class4 C4 = new Class4(C1.driver);
    C4.headerMenu();
    Class5 C5 = new Class5(C1.driver);
    GlobalWait.setDriver(C5.driver);
    C5.windowHandle();

}
public void windowHandle() throws InterruptedException {

    Set<String> handles = driver.getWindowHandles();

    for (String handle : handles) {
        driver.switchTo().window(handle);
    }

    GlobalWait.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[2]/div[2]/div[1]/div[3]/div[1]/a/h3[text()='Honeymoon Hotspots']"))).click();
 }

}
