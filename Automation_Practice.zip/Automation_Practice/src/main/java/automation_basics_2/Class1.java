package automation_basics_2;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class Class1 {

    //Usage of a common Webdriver wait class

    WebDriver driver;

    public static void main(String[] args) throws InterruptedException {


        Class1 c1=new Class1();
        GlobalWait.setDriver(c1.driver);
        c1.navigateToMakeMyTrip();
        c1.HoverOverMethod();
        c1.HoverOverMethod2();


    }

    public Class1(){

        System.setProperty("webdriver.chrome.driver", "C:/ChromeDriver/chromedriver-win64/chromedriver.exe");
        this.driver= new ChromeDriver();
        driver.manage().window().maximize();

    }

    public void navigateToMakeMyTrip() {

        driver.get("https://www.makemytrip.com");
    }

    public void HoverOverMethod() throws InterruptedException {


        WebElement element = driver.findElement(By.xpath("//p[text()='Business Travel Solution']"));
        Actions actions = new Actions(driver);
        actions.moveToElement(element).build().perform();
        Thread.sleep(2000);

    }

    public void HoverOverMethod2() throws InterruptedException {

        WebElement element = driver.findElement(By.xpath("//p[text()='SWITCH TO MYBIZ']"));
        GlobalWait.wait.until( ExpectedConditions.visibilityOf(element)).click();
        GlobalWait.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@class='inputText']"))).sendKeys("gmail");
        GlobalWait.wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[@class='mybizLoginClose']"))).click();

    }

}
