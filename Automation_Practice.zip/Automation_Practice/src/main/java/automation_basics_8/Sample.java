package automation_basics_8;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Sample {
    private static WebDriver driver;
    private static WebDriverWait wait;
    public Sample(){

    System.setProperty("webdriver.chrome.driver", "C:/ChromeDriver/chromedriver-win64/chromedriver.exe");
    this.driver= new ChromeDriver();
    driver.manage().window().maximize();
    this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));

    }

// //*[@id="EXPAND-OUTERFRAME"]/div[2]/div/div/div/div[3]/div/div
    public static void main(String[] args) throws InterruptedException {

            Sample sample = new Sample();
            driver.get("https://oehcitizensuat.b2clogin.com/oehcitizensuat.onmicrosoft.com/b2c_1a_signin_servicenswandlocal_eplanning/oauth2/v2.0/authorize?redirect_uri=https%3A%2F%2Fapps-uat.planningportal.nsw.gov.au%2Fprweb%2FPRAuth&client_id=af86bbda-7abd-4c5a-b6f1-4df2f85d72de&scope=openid%20https://OEHCitizensUAT.onmicrosoft.com/api/User.Read%20&state=da89178a1cef1d13efbe0fec97e117d5bcfa30c226fb9026a1fdd648d06546a4_app/default&nonce=1dcd85ae1f2811f30c5315e0b8c6d00efa5805e22a6be26b597d928f40b8837c&response_type=code");
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='signInName']"))).sendKeys("econapplicant1@yopmail.com");
            driver.findElement(By.xpath("//input[@id='password']")).sendKeys("rules@123");
            driver.findElement(By.xpath("//button[@id='next']")).click();
            driver.manage().window().maximize();
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("appview-nav-toggle-one"))).click();
            driver.findElement(By.linkText("New")).click();
            driver.findElement(By.cssSelector(".menu-item:nth-child(6) .menu-item-title")).click();
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='NSW Planning Portal']"))).isEnabled();
            driver.switchTo().frame(1);
            driver.findElement(By.id("a30883dd")).click();
            WebElement element = driver.findElement(By.xpath("//select[@name='$PpyWorkPage$pApplicant$pPersonalInformation$ppyTitle']"));
            Select select = new Select(element);
            select.selectByVisibleText("Mr");
            driver.findElement(By.xpath("//input[@name='$PpyWorkPage$pApplicant$pPersonalInformation$pFirstName']")).clear();
            driver.findElement(By.xpath("//input[@name='$PpyWorkPage$pApplicant$pPersonalInformation$pFirstName']")).sendKeys("Nawaz");
            driver.findElement(By.xpath("//input[@name='$PpyWorkPage$pApplicant$pAddress$pFULLADDRESS']")).sendKeys("186 BLACKTOWN ROAD BLACKTOWN 2148");
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//tr[@class='oddRow cellCont']/td/div/div"))).click();
            WebElement element_1 = driver.findElement(By.xpath("//section/div/div/div/div/div/div/div/div[2]/div[2]/div/div/div/div[3]/div/div"));

        if(element_1.isDisplayed()){
            WebElement element_2 = element_1.findElement(By.xpath("//label[@for='014caf52']"));
            JavascriptExecutor jsc = (JavascriptExecutor) driver;
            jsc.executeScript("arguments[0].style.border='3px solid green'", element_2);
//                if(element_2.isDisplayed()){
//                    WebElement element_3 = element_2.findElement(By.xpath("//div[@id='EXPAND-OUTERFRAME']/div[2]/div/div/div/div[3]/div/div/div/div/div[1]/span/label"));
//                    element_3.click();
//                }

            }


    }
}


