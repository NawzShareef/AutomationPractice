package automation_basics_6;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Steps_Definition_1 {

    //Using a default class constructor for browser initialization
    private static WebDriver driver;

    public Steps_Definition_1() {

        System.setProperty("webdriver.chrome.driver", "C:/ChromeDriver/chromedriver-win64/chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();

    }

    @Given("I am on the {string} on make my trip")
    public void i_am_on_the_on_make_my_trip(String string) {
        driver.get("https://www.makemytrip.com");
    }

    @When("I hover on {string}")
    public void i_hover_on(String myBiz) {
        Actions action = new Actions(driver);
        action.moveToElement(driver.findElement(By.xpath("//span[text()='" + myBiz + "']"))).perform();
    }

    @Then("I am on {string}")
    public void i_am_on(String planningTrip) {
        driver.findElement(By.xpath("//p[text()='" + planningTrip + " ?']")).isEnabled();
    }

    @Then("I click on {string}")
    public void i_click_on(String string) {
        driver.findElement(By.xpath("//p[text()='SWITCH TO MYBIZ']")).click();
    }

    @Then("I am on the {string}")
    public void i_am_on_the(String planningTrip) {
        driver.findElement(By.xpath("//p[text()='Login/Sign up']")).isDisplayed();
    }
}
