package automation_basics_3;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.HashMap;

public class Driver_chrome {

    //Non usage of System.setProperty or setup command for initialization
    //Chrome driver initialization

    public static WebDriver driver;

    private static final HashMap<String, Class<?>> driverMap = new HashMap<String, Class<?>>() {
        {
            put("chrome", ChromeDriver.class);
        }
    };

    public static WebDriver add(String browser) throws Exception {
        if (browser.equals("chrome")) {
            Class<?> driverClass = driverMap.get(browser);
            driver = (WebDriver) driverClass.newInstance();
        }
        return driver;
    }



}
