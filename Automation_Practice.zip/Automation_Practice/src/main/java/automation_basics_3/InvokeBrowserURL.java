package automation_basics_3;

public class InvokeBrowserURL {


    public static void main(String[] args) throws Exception {
        Driver_chrome.add("chrome");
        Driver_chrome.driver.get("https://www.makemytrip.com");

    }
}
